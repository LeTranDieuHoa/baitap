import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
  
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

 @override
Widget build(BuildContext context) {
  EdgeInsets a2, a; // Thêm dấu phẩy sau dòng này
  return DefaultTabController(
    length: 3,
    child: Scaffold(
      appBar: AppBar(
        title: Text("Banner Example"),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(40),
          child: Align(
            alignment: Alignment.centerLeft,
            child: TabBar(
              tabs: [
                Row(children: [Icon(Icons.directions_car), SizedBox(width:5), Text("Car")]),
                Row(children: [Icon(Icons.directions_transit), SizedBox(width:5), Text("Transit")]),
                Row(children: [Icon(Icons.directions_bike), SizedBox(width:5), Text("Bike")]),
              ],
              indicator: ShapeDecoration(
                shape: UnderlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.transparent,
                    width: 0,
                    style: BorderStyle.solid,
                  )
                ),
                gradient: LinearGradient(colors: [Color(0xff0081ff), Color(0xff01ff80)])
              )
            )
          ),
        ),
      ),
      body: Banner(
        message: 'Offer 20% off',
        location: BannerLocation.topStart,
        color: Colors.red,
        child: Container(
          height: 150,
          width: double.infinity,
          color: Colors.lightGreen,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                Image.network(
                  "https://raw.githubusercontent.com/o7planning/rs/master/flutter/fast_food.png"
                ),
                SizedBox(width: 10),
                Column(
                  children: [
                    Text("Fast Food", style: TextStyle(fontSize: 30, color: Colors.blue)),
                    SizedBox(height: 10),
                    Text("Description ....", style: TextStyle(fontStyle: FontStyle.italic))
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    ),
  );
}
}


