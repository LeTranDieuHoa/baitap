import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  MyHomePageState createState() => MyHomePageState();
}

class MyHomePageState extends State<MyHomePage> {
  int selectedIndex = 0;
  Widget _myContacts = MyContacts();
  Widget _myEmails = MyEmails();
  Widget _myProfile = MyProfile();

  @override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Text("BottomNavigationBar Example"),
    ),
    body: getBody(),
    bottomNavigationBar: BottomNavigationBar(
      currentIndex: this.selectedIndex,
      selectedIconTheme: IconThemeData(
        color: Colors.red,
        opacity: 1.0,
        size: 45,
      ),
      unselectedIconTheme: IconThemeData(
        color: Colors.black45,
        opacity: 0.5,
        size: 25,
      ),
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.contacts),
          label: "Contacts",
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.mail),
          label: "Emails",
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.person),
          label: "Profile",
        )
      ],
      onTap: (int index) {
        this.setState(() {
          this.selectedIndex = index;
        });
      },
    ),
  );
}

  Widget getBody() {
    if (selectedIndex == 0) {
      return _myContacts;
    } else if (selectedIndex == 1) {
      return _myEmails;
    } else {
      return _myProfile;
    }
  }

  void onTapHandler(int index) {
    setState(() {
      selectedIndex = index;
    });
  }
}

class MyContacts extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Contacts"));
  }
}

class MyEmails extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Emails"));
  }
}

class MyProfile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Profile"));
  }
}